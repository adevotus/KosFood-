
<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>KosFood</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
	<!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
	<!-- Start header -->
	<header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="index.html">
				<img src="images/weblogo.png" alt="" />
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-rs-food">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
						<li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
						
						<li class="nav-item"><a class="nav-link" href="restaurant.php">Restaurants</a></li>
						
						<li class="nav-item active"><a class="nav-link" href="contact.php">Contact</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->
	
	<!-- Start All Pages -->
	<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Contact</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- End All Pages -->
	
	<!-- Start Contact -->
	
	<div class="contact-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Please leave your message here</h2>
						<p>We would like to hear something from you about our service</p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12">
				<form action="get_responce.php" method="POST">
				
					
					
					<div style="width:700px;"><input type="text" class="form-control" name="email"  placeholder="Your email" required data-error="Please enter your email"></div>
				    <br>
					
					<div style="width:700px;height:35px;"><input type="text" class="form-control" name="comments"  placeholder="Your message" required data-error="Please enter your comments" style="height:30px;"></div>
                      <br>
				   <button type="submit" class="btn btn-suceess">send</button>
				</form>
				<?php 
    require_once("config.php");
    require_once("contact.php");

    if((isset($_POST['email'])&& $_POST['email'] !='') && (isset($_POST['comments'])&& $_POST['comments'] !=''))
    {
    
	
    $yourEmail = $conn->real_escape_string($_POST['email']);
   
    $comments = $conn->real_escape_string($_POST['comments']);
    $sql="INSERT INTO contact_tb (email,comments) VALUES ('".$yourEmail."', '".$comments."')";
	 
	 
    if(!$result = $conn->query($sql)){
    die('There was an error running the query ['. $conn->error . ']');
	
    }
    else
    {
        echo "succeffuly";
    }
    }
    else
    {
        echo "";
    }

    ?>
			</div>
			</div>
		</div>
	</div>
	
	<!-- End Contac
	

	
	
<!-- Start Footer -->
<footer class="footer-area bg-f">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<h3>About Us</h3>
					<p>Best food delivery platform aiming to serve our customers with quality services from their favourite restaurants  </p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Social medias</h3>
					
					<ul class="list-inline f-social">
						<li class="list-inline-item"><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Contact information</h3>
					<p class="lead">Buni Hub,Dar es salaam, Tanzania</p>
					<p class="lead"><a href="#">+255 7... ....</a></p>
					<p><a href="#"> kosfood@gmail.com</a></p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Working hours</h3>
					<p><span class="text-color">Everyday: </span>7am-11pm</p>
					
				</div>
			</div>
		</div>
		
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<p class="company-name">All Rights Reserved. &copy; 2020 <a href="#">KosFood</a></p>
					</div>
				</div>
			</div>
		</div>
		
	</footer>
	<!-- End Footer -->
	
	<a href="#" id="back-to-top" title="Back to top" style="display: none;"><i class="fa fa-angle-up"></i></a>

	<!-- ALL JS FILES -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
	
	<script src="js/jquery.superslides.min.js"></script>
	<script src="js/images-loded.min.js"></script>
	<script src="js/isotope.min.js"></script>
	<script src="js/baguetteBox.min.js"></script>
	<script src="js/jquery.mapify.js"></script>
	<script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
	
</body>
</html>
<?php
require 'config.php';
if(isset($_POST['send'])){
	require_once 'get_responce.php';
}
?>