<?php 
    require_once("config.php");
    require_once("contact.php");

    if((isset($_POST['email'])&& $_POST['email'] !='') && (isset($_POST['comments'])&& $_POST['comments'] !=''))
    {
    
	
    $yourEmail = $conn->real_escape_string($_POST['email']);
   
    $comments = $conn->real_escape_string($_POST['comments']);
    $sql="INSERT INTO contact_tb (email,comments) VALUES ('".$yourEmail."', '".$comments."')";
	 
	 
    if(!$result = $conn->query($sql)){
    die('There was an error running the query ['. $conn->error . ']');
	
    }
    else
    {
        echo "";
    }
    }
    else
    {
        echo "";
    }

    ?>
  
