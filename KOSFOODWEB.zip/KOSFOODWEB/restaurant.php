<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>KosFood</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="images/favicon.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">    
	<!-- Site CSS -->
    <link rel="stylesheet" href="css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">

    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
	<!-- Start header -->
	<header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="index.php">
				<img src="images/weblogo.png" alt="" />
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-rs-food">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
						<li class="nav-item"><a class="nav-link" href="menu.php">Menu</a></li>
						
						<li class="nav-item active"><a class="nav-link" href="restaurant.php">Restaurants</a></li>
						
						<li class="nav-item"><a class="nav-link" href="contact.php">Contact</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->
	
	<!-- Start All Pages -->
	<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>our working Restaurant</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- End All Pages -->
	
	<!-- Start blog -->
	<div class="blog-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Restaurant</h2>
						<p>Best and Quality Restaurants from different areas in Dar es salaam. </p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-01.jpg" alt="">
						</div>
						<div class="blog-detail">
							<h2 style="font-family:arial black">CASH AND CARRY</h2>
							<ul>
								
							</ul>
							<p>a great restaurant that provides quality food service to customers through our lively and gentle staff capable of providing excellent service.
                              We accept various food orders for celebrations such as Weddings and gatherings for any number of consumers.
                              Cash and carry is here for you to provide you with a unique food and beverage service that you can't find anywhere else.

                            </p>
					
                            <div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-02.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">SALATHAI</h2>
							
							<p>Do you like to get quality food and good taste at affordable prices..welcome to our restaurant located in Dar es salaam kinondoni.  
                                Our restaurant offers excellent food and beverage services with a well-designed seating area and tables where the customer will be able to enjoy and be served by the cheerful and hospitable staff. </p>
							
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
                        </div>
                        
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-03.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">KHANA KHAZANA</h2>
							
							<p>is a great place to have fun with your close people such as family and friends.  we offer unique food and soft drinks service as well as excellent service delivery food orders.  We are located in the heart of Dar es Salaam city where we can serve our customers with ease and high quality.  Our foods are unique and indigenous to different parts of the world. </p>
							
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-04.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">ROZALIA</h2>
							
							<p> is a popular restaurant in Dar es Salaam that provides quality food and beverage services.  Our restaurant has a beautiful landscape bordering the Indian Ocean that boasts a beautiful climate as well as a fascinating environment.  
                        We cook all kinds of foods including sea food and indigenous foods of various ethnic groups in Tanzania.</p>
							               
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-05.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">DOTEE</h2>
							
							<p>is an environmentally friendly restaurant that offers excellent food and beverage services of all kinds.  Our foods are foods that are prepared in a hygienic manner and of the highest quality to the delight of our customer.  Our staff are smart and fluent and have a high 
                             ability to listen to the client and know what they need.  very welcome to get the best food service for your health. </p>
							
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-06.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">NEXUS</h2>
							
							<p>is a restaurant known for its excellent food and beverage service at very affordable prices.  Our foods are of a wide range of natural ingredients and are prepared with the highest standards of cleanliness and quality through our chefs who specialize in the best cuisine of all foods.  Our restaurant has a great environment for access to food and beverage services with family or friends</p>
						
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-07.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">SAMAKI SAMAKI</h2>
							
							<p>Welcome to Samaki Samaki for the best Service of a variety of foods with good taste and hygiene. Our staff is very generous and able to provide you with the best service you will be interested in.  We serve customers in an efficient and unique manner as well as providing customer property security service.  We have a large parking lot for high quality car protection</p>
							
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-08.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">KFC</h2>
							
							<p>is the best restaurant in the world famous for its excellent way of preparing sweet chicken with unique ingredients to please the customer. 
                                 We provide chicken, Chips and soft drinks in our restaurants and are available in various locations in Dar es Salaam to reach our customers. Our restaurants have adequate security as well as good parking for our customers who will come with transport.. </p>
							
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-12">
					<div class="blog-box-inner">
						<div class="blog-img-box">
							<img class="img-fluid" src="images/blog-img-09.jpg" alt="">
						</div>
						<div class="blog-detail">
                        <h2 style="font-family:arial black">SUBWAY</h2>
							
							<p>is a great bull restaurant located in Mlimani city and other location in dar es Salaam that offers the best food and beverage services.  We have a great environment within our restaurant as well as wonderful, attractive and responsive waiters for all customers.  If you need good and unique foods with good taste around our restaurant </p>
				
							<div class="blog-tag-box">
							<ul class="list-inline tag-list">
								<li class="list-inline-item"><a href="menu.php"><strong>View menu list </strong></a></li>
								<li class="list-inline-item"><a href="#"><strong>Track location</strong></a></li>
								
								
							</ul>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- End blog -->
	
	
	
		<!-- Start Footer -->
        <footer class="footer-area bg-f">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<h3>About Us</h3>
					<p>Best food delivery platform aiming to serve our customers with quality services from their favourite restaurants  </p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Social medias</h3>
					
					<ul class="list-inline f-social">
						<li class="list-inline-item"><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Contact information</h3>
					<p class="lead">Buni Hub,Dar es salaam, Tanzania</p>
					<p class="lead"><a href="#">+255 7... ....</a></p>
					<p><a href="#"> kosfood@gmail.com</a></p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Working hours</h3>
					<p><span class="text-color">Everyday: </span>7am-11pm</p>
					
				</div>
			</div>
		</div>
		
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<p class="company-name">All Rights Reserved. &copy; 2020 <a href="#">KosFood</a></p>
					</div>
				</div>
			</div>
		</div>
		
	</footer>
	<!-- End Footer -->
	
	<a href="#" id="back-to-top" title="Back to top" style="display: none;"><i class="fa fa-angle-up"></i></a>
	<!-- ALL JS FILES -->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/popper.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
	
	<script src="js/jquery.superslides.min.js"></script>
	<script src="js/images-loded.min.js"></script>
	<script src="js/isotope.min.js"></script>
	<script src="js/baguetteBox.min.js"></script>
	<script src="js/form-validator.min.js"></script>
    <script src="js/contact-form-script.js"></script>
    <script src="js/custom.js"></script>
</body>
</html>