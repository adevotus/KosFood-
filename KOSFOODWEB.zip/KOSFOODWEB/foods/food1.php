<!DOCTYPE html>
<html lang="en"><!-- Basic -->
<head>
	<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
 
     <!-- Site Metas -->
    <title>KosFood</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Site Icons -->
    <link rel="shortcut icon" href="../images/favicon.png" type="image/x-icon">
    <link rel="apple-touch-icon" href="../images/apple-touch-icon.png">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="../css/bootstrap.min.css"> 
    <link rel="stylesheet" href="../css/sweetalert2.all.min.css"> 
    <link rel="stylesheet" href="../css/sweetalert2.min"> 
    <link rel="stylesheet" href="../css/sweetalert2.all"> 
    <link rel="stylesheet" href="../css/sweetalert2"> 
       
	<!-- Site CSS -->
    <link rel="stylesheet" href="../css/style.css">    
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="../css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../css/custom.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
	<!-- Start header -->
	<header class="top-navbar">
		<nav class="navbar navbar-expand-lg navbar-light bg-light">
			<div class="container">
				<a class="navbar-brand" href="../index.php">
				<img src="../images/weblogo.png" alt="" />
				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbars-rs-food" aria-controls="navbars-rs-food" aria-expanded="false" aria-label="Toggle navigation">
				  <span class="navbar-toggler-icon"></span>
				</button>
				<div class="collapse navbar-collapse" id="navbars-rs-food">
					<ul class="navbar-nav ml-auto">
						<li class="nav-item"><a class="nav-link" href="../index.php">Home</a></li>
						<li class="nav-item"><a class="nav-link" href="../menu.php">Menu</a></li>
						
						<li class="nav-item"><a class="nav-link" href="../restaurant.php">Restaurant</a></li>
						
						<li class="nav-item"><a class="nav-link" href="../contact.php">Contact</a></li>
					</ul>
				</div>
			</div>
		</nav>
	</header>
	<!-- End header -->
	
	<!-- Start All Pages -->
	<div class="all-page-title page-breadcrumb">
		<div class="container text-center">
			<div class="row">
				<div class="col-lg-12">
					<h1>Food and Drinks Nutrition</h1>
				</div>
			</div>
		</div>
	</div>
	<!-- End All Pages -->
	
	<!-- Start blog details -->
	<div class="blog-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>FOOD & DRINKS</h2>
						<p>Best Food and Drinks with great tasteful</p>
						</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xl-8 col-lg-8 col-12">
					 <div id="foodDisplay">
						<!-- here are the template -->
						<div class="blog-inner-details-page">
	<div class="blog-inner-box">
		<div class="side-blog-img">
			<img class="img-fluid" src="../images/img-04.jpg" alt="">
			<div class="date-blog-up"></div>
		</div>
		<div class="inner-blog-detail details-page">
			<h3>Leedies Brown Tonic.</h3>
			<ul>
				<li><i class="zmdi zmdi-account"></i>Restaurant : <span>NEXUS</span></li>
				<li>|</li>
				<li><i class="zmdi zmdi-time"></i>Amount : <span>Tsh 5000</span></li>
			</ul>

			<p> A jorney that begin with Sweet, tropical fruit, buttery caramel and vanilla notes and ends with
				a smoky liquorice and molasses finish. savor every moment of it.
			</p>
			<h2>What's your addition?</h2>
			<div class="col-md-12" style="width:200px;">
				<div class="form-group">
					<select class="custom-select d-block form-control" id="person" required
						data-error="Please select Person">
						<option disabled selected>Food degredence*</option>
						<option value="1">pilipil</option>
						<option value="2">maji</option>
						<option value="3">3</option>

					</select>

				</div>
			</div>

			<div class="blog-tag-box">
				<h3>What your desicion</h3>
				<ul class="list-inline tag-list">
					<div class="checkbox">
						<label><input type="radio" name="remember" action="default"> pick up</label>
					</div>
					<div class="checkbox">
						<label><input type="radio" name="remember"> Delivery</label>
					</div>
					<li class="list-inline-item">
						<div>
							<h3>Amount:Tsh5000</h3>
						</div>
					</li>

					<button id="submit" class="btnAddAction"><a href="../cartproduct.php">add to cart</a></button>
					<button id="submit" class="btnAddAction"><a href="../login.php">order now</a></button>
					<script>
						function submit() {
							Swal.fire(
								'good job!',
								'your clicked the button',
								'success'
							)
						}
					</script>

				</ul>
			</div>
		</div>

	</div>

</div>
						
						
					 </div>
				</div>
				<div class="col-xl-4 col-lg-4 col-md-6 col-sm-8 col-12 blog-sidebar">
					<div class="right-side-blog">
						<h3>Most ordered</h3>
						<div class="post-box-blog">
							<div class="recent-post-box">
								<div class="recent-box-blog">
									<div class="recent-img">
										<img class="img-fluid" src="../images/post-img-new.jpg" alt="">
									</div>
									<div class="recent-info">
										<ul>
											<li><i class="zmdi zmdi-account"></i>Restaurant : <span>DOTEE</span></li>
											<li>|</li>
											
										</ul>
										<span>Hot-Bager<h3>Tsh 10000</h3><a  href="../food_one.php"><h3 style="margin-left:90px;margin-top:-42px;color:#d65106;font-family:arial black;">order now</h3></a></span> 
										
									</div>
								</div>
								<div class="recent-box-blog">
									<div class="recent-img">
										<img class="img-fluid" src="../images/img-food2.jpg" alt="">
									</div>
									<div class="recent-info">
										<ul>
											<li><i class="zmdi zmdi-account"></i>Restaurant : <span>KFC</span></li>
											<li>|</li>
										
										</ul>
										<span>Delicious and Tasteful Fried Chicken <h3>Tsh 10000</h3><a class="loadlink" href="food2.php"><h3 style="margin-left:90px;margin-top:-42px;color:#d65106;font-family:arial black;">order now</h3></a></span>
										
									</div>
								</div>
								<div class="recent-box-blog">
									<div class="recent-img">
										<img class="img-fluid" src="../images/imgsmall.jpg" alt="">
									</div>
									<div class="recent-info">
										<ul>
											<li><i class="zmdi zmdi-account"></i>Restaurant : <span>ROZALIA</span></li>
											<li>|</li>
											
										</ul>
										<span>Special Green Fruits<h3>Tsh 3000</h3><a href="food4.php"><h3 style="margin-left:90px;margin-top:-42px;color:#d65106;font-family:arial black;">order now</h3></a></span>
									</div>
								</div>
								<div class="recent-box-blog">
									<div class="recent-img">
										<img class="img-fluid" src="../images/img-food3.jpg" alt="">
									</div>
									<div class="recent-info">
										<ul>
											<li><i class="zmdi zmdi-account"></i>Restaurant : <span>SUBWAY</span></li>
											<li>|</li>
										
										</ul>
										<span>Special Green Fruits<h3>Tsh 3000</h3><a href="food3.php"><h3 style="margin-left:90px;margin-top:-42px;color:#d65106;font-family:arial black;">order now</h3></a></span>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
			
			</div>
		</div>
	</div>
	<!-- End details -->
		<!-- Start Gallery -->
        <div class="gallery-box">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="heading-title text-center">
						<h2>Other related food</h2>
						<p>Pick up your Favorite One to Enjoy Yourself</p>
					</div>
				</div>
			</div>
			<div class="tz-gallery">
				<div class="row">
					<div class="col-sm-12 col-md-4 col-lg-4">
                        <a class="lightbox" href="../food_one.php">
                       
                            <img class="img-fluid" src="../images/gallery-img-01.jpg" alt="Gallery Images">
                        											
						</a>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-4">
						<a class="lightbox" href="../images/gallery-img-02.jpg">
							<img class="img-fluid" src="../images/gallery-img-02.jpg" alt="Gallery Images">
						</a>
					</div>
					<div class="col-sm-6 col-md-4 col-lg-4">
						<a class="lightbox" href="../images/gallery-img-03.jpg">
							<img class="img-fluid" src="../images/gallery-img-03.jpg" alt="Gallery Images">
						</a>
					</div>
					
					
					
				</div>
			</div>
		</div>
	</div>
	<!-- End Gallery -->
	
	

	

	<!-- Start Footer -->
	<footer class="footer-area bg-f">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<h3>About Us</h3>
					<p>Best food delivery platform aiming to serve our customers with quality services from their favourite restaurants  </p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Social medias</h3>
					
					<ul class="list-inline f-social">
						<li class="list-inline-item"><a href="#"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-linkedin" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-google-plus" aria-hidden="true"></i></a></li>
						<li class="list-inline-item"><a href="#"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
					</ul>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Contact information</h3>
					<p class="lead">Buni Hub,Dar es salaam, Tanzania</p>
					<p class="lead"><a href="#">+255 7... ....</a></p>
					<p><a href="#"> kosfood@gmail.com</a></p>
				</div>
				<div class="col-lg-3 col-md-6">
					<h3>Working hours</h3>
					<p><span class="text-color">Everyday: </span>7am-11pm</p>
					
				</div>
			</div>
		</div>
		
		<div class="copyright">
			<div class="container">
				<div class="row">
					<div class="col-lg-12">
						<p class="company-name">All Rights Reserved. &copy; 2020 <a href="#">KosFood</a></p>
					</div>
				</div>
			</div>
		</div>
		
	</footer>
	<!-- End Footer -->
		<a href="#" id="back-to-top" title="Back to top" style="display: none;"><i class="fa fa-angle-up"></i></a>
	<!-- ALL JS FILES -->
	<script src="../js/jquery-3.2.1.min.js"></script>
	<script src="../js/popper.min.js"></script>
	<script src="../js/bootstrap.min.js"></script>
    <!-- ALL PLUGINS -->
	
	<script src="../js/jquery.superslides.min.js"></script>
	<script src="../js/images-loded.min.js"></script>
	<script src="../js/isotope.min.js"></script>
	<script src="../js/baguetteBox.min.js"></script>
	<script src="../js/form-validator.min.js"></script>
    <script src="../js/contact-form-script.js"></script>
	<script src="../js/custom.js"></script>
	<!-- <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10">
  $(function() {
    $('#submit').click(function() {
        Swal.fire({
                 icon: 'error',
                 title: 'Oops...',
                text: 'Something went wrong!',
                footer: '<a href="#">Why do I have this issue?</a>'
            })
        })
    
     })

	  </script> -->
	 <!-- <script>
	  function submit(){
		  Swal.fire({
                 icon: 'success',
                 title: 'ordered ',
                text: 'please login/register to pay your order',
                footer: '<a href="login.php"><h2 style="color:#010101; font-size:20px;"><i class="fa fa-sign-in"></i> Login</h2></a>'
            })

	  }
	   </script> -->
	   <script>
	   function submit(){
		   alert("click here");
	   }
	   
	   </script>


</body>
</html>